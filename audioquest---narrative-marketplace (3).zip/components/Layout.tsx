
import React, { useState, useRef, useEffect } from 'react';
import { Page, User, FooterLink, SocialLinks, AppNotification } from '../types';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
  activePage: Page;
  setActivePage: (page: Page) => void;
  user: User;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  onMarkRead: () => void;
  onLogout: () => void;
  footerLinks: FooterLink[][];
  footerDescription: string;
  announcement: string;
  socialLinks: SocialLinks;
  footerCdImages: string[];
}

const Layout: React.FC<LayoutProps> = ({ children, activePage, setActivePage, user, theme, toggleTheme, onMarkRead, onLogout, footerLinks, footerDescription, announcement, socialLinks, footerCdImages }) => {
  const [isInboxOpen, setIsInboxOpen] = useState(false);
  const inboxRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (inboxRef.current && !inboxRef.current.contains(event.target as Node)) {
        setIsInboxOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!user) return null;

  const unreadCount = user.notifications ? user.notifications.filter(n => !n.read).length : 0;

  const navItems = [
    { id: Page.HOME, icon: 'fa-house', label: 'Home' },
    { id: Page.EXPLORE, icon: 'fa-compass', label: 'Explore' },
    { id: Page.STUDIO, icon: 'fa-microphone-lines', label: 'Studio' },
    { id: Page.STORE, icon: 'fa-coins', label: 'Store' },
    { id: Page.WALLET, icon: 'fa-wallet', label: 'Hub Center' },
  ];

  return (
    <div className="flex flex-col h-screen overflow-hidden theme-transition">
      {/* Top Announcement Bar */}
      <div className="bg-indigo-600 h-10 flex items-center overflow-hidden relative border-b border-indigo-500 shadow-xl shrink-0 z-[60]">
        <div className="flex items-center gap-6 animate-marquee whitespace-nowrap min-w-full">
           {[...Array(6)].map((_, i) => (
             <span key={i} className="text-white text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-4">
               <i className="fa-solid fa-circle-bolt text-indigo-300"></i>
               {announcement}
             </span>
           ))}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <aside className="hidden md:flex w-64 border-r border-neutral-200 dark:border-neutral-800 flex-col bg-white dark:bg-neutral-950 transition-all duration-300">
          <div className="p-8 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <i className="fa-solid fa-headphones text-xl text-white"></i>
            </div>
            <span className="font-bold text-xl tracking-tight text-neutral-900 dark:text-white uppercase italic">AQ Hub</span>
          </div>

          <nav className="flex-1 px-4">
            <ul className="space-y-2">
              {navItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActivePage(item.id)}
                    className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
                      activePage === item.id 
                        ? 'bg-indigo-600 text-white shadow-lg' 
                        : 'text-neutral-500 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                    }`}
                  >
                    <i className={`fa-solid ${item.icon} w-6 text-center text-lg`}></i>
                    <span className="font-black text-[10px] uppercase tracking-widest">{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <div className="p-4 mt-auto space-y-2">
            <button 
               onClick={() => setActivePage(Page.WALLET)}
               className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 p-3 rounded-xl flex items-center gap-3 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500">
                <i className="fa-solid fa-coins"></i>
              </div>
              <div className="text-left">
                <p className="text-[10px] text-neutral-500 font-black uppercase">Balance</p>
                <p className="text-sm font-black text-amber-500">{user.coins} Coins</p>
              </div>
            </button>
            <button 
              onClick={onLogout}
              className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-neutral-400 hover:text-rose-500 transition-all"
            >
              <i className="fa-solid fa-right-from-bracket w-6 text-center"></i>
              <span className="font-black text-[10px] uppercase tracking-widest">Logout</span>
            </button>
          </div>
        </aside>

        <main className="flex-1 flex flex-col overflow-hidden relative">
          <header className="h-16 md:h-20 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between px-4 md:px-8 bg-white/80 dark:bg-neutral-950/80 backdrop-blur-md z-[50] transition-colors">
            <div className="flex items-center gap-3 md:hidden">
               <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md">
                 <i className="fa-solid fa-headphones text-sm text-white"></i>
               </div>
               <span className="font-bold text-lg text-neutral-900 dark:text-white uppercase italic">AQ</span>
            </div>

            <div className="flex-1 max-w-md mx-4">
              <div className="relative">
                <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 dark:text-neutral-500 text-xs"></i>
                <input 
                  type="text" 
                  placeholder="Search Narrative Hub..." 
                  className="w-full bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-full py-2 pl-9 pr-4 text-xs md:text-sm focus:outline-none focus:border-indigo-500 transition-all text-neutral-900 dark:text-neutral-100 font-medium"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-5">
              <button 
                onClick={toggleTheme}
                className="w-10 h-10 rounded-xl bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center text-neutral-600 dark:text-neutral-400 hover:text-indigo-600 border border-neutral-200 dark:border-neutral-800 transition-all"
              >
                {theme === 'dark' ? <i className="fa-solid fa-sun text-sm"></i> : <i className="fa-solid fa-moon text-sm"></i>}
              </button>

              <div className="relative" ref={inboxRef}>
                <button 
                  onClick={() => { setIsInboxOpen(!isInboxOpen); onMarkRead(); }}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-all relative ${isInboxOpen ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg' : 'bg-neutral-100 dark:bg-neutral-900 text-neutral-600 dark:text-neutral-400 hover:text-indigo-600 border-neutral-200 dark:border-neutral-800'}`}
                >
                  <i className="fa-solid fa-bell text-lg"></i>
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 rounded-full border-2 border-white dark:border-neutral-950 flex items-center justify-center text-[8px] text-white font-black animate-bounce">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* NOTIFICATION DROPDOWN */}
                {isInboxOpen && (
                  <div className="absolute right-0 mt-4 w-[320px] bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] shadow-2xl overflow-hidden z-[100] animate-in fade-in slide-in-from-top-4">
                    <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex justify-between items-center bg-neutral-50/50 dark:bg-neutral-950/50">
                       <h3 className="text-xs font-black uppercase tracking-widest text-neutral-900 dark:text-white italic">Narrative Inbox</h3>
                       <span className="text-[8px] font-black uppercase bg-indigo-600/10 text-indigo-600 px-2 py-0.5 rounded-full">{user.notifications?.length || 0} Total</span>
                    </div>
                    <div className="max-h-[400px] overflow-y-auto">
                       {user.notifications && user.notifications.length > 0 ? (
                         <div className="divide-y divide-neutral-100 dark:divide-neutral-800">
                           {user.notifications.map((notif: AppNotification) => (
                             <div key={notif.id} className={`p-5 space-y-2 transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-950 ${!notif.read ? 'border-l-4 border-indigo-600' : ''}`}>
                                <div className="flex justify-between items-start gap-3">
                                   <p className="text-[10px] font-black text-neutral-900 dark:text-white uppercase italic leading-tight">{notif.title}</p>
                                   <span className="text-[7px] font-black text-neutral-400 shrink-0">{notif.timestamp}</span>
                                </div>
                                <p className="text-[10px] font-medium text-neutral-500 dark:text-neutral-400 leading-relaxed italic">{notif.message}</p>
                             </div>
                           ))}
                         </div>
                       ) : (
                         <div className="p-10 text-center space-y-3">
                            <i className="fa-solid fa-inbox text-3xl text-neutral-200 dark:text-neutral-800"></i>
                            <p className="text-[9px] font-black text-neutral-400 uppercase tracking-widest">Your inbox is clear</p>
                         </div>
                       )}
                    </div>
                    <div className="p-4 bg-neutral-50 dark:bg-neutral-950 border-t border-neutral-100 dark:border-neutral-800">
                       <button onClick={() => setIsInboxOpen(false)} className="w-full py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-[9px] font-black uppercase tracking-widest text-neutral-500 hover:text-indigo-600 transition-colors shadow-sm">Close Center</button>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <div className="text-right hidden lg:block">
                  <p className="text-sm font-black truncate max-w-[120px] text-neutral-900 dark:text-white">{user.username}</p>
                  <div className="flex items-center justify-end gap-1 text-[9px] text-indigo-500 font-black uppercase">
                    <i className="fa-solid fa-shield-halved"></i>
                    {user.role}
                  </div>
                </div>
                <img src={user.avatar} alt="Avatar" className="w-8 h-8 md:w-10 md:h-10 rounded-full border border-neutral-200 dark:border-neutral-700 object-cover shadow-sm" />
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto theme-transition">
            <div className="p-4 md:p-8 pb-32">
              {children}
            </div>
            <Footer linkColumns={footerLinks} description={footerDescription} socialLinks={socialLinks} cdImages={footerCdImages} />
          </div>
        </main>
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 25s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default Layout;
