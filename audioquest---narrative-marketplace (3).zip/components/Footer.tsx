
import React, { useState } from 'react';
import { FooterLink, SocialLinks } from '../types';

interface FooterProps {
  linkColumns: FooterLink[][];
  description: string;
  socialLinks: SocialLinks;
  cdImages: string[];
}

const Footer: React.FC<FooterProps> = ({ linkColumns, description, socialLinks, cdImages }) => {
  const [activeContent, setActiveContent] = useState<FooterLink | null>(null);

  const handleLinkClick = (e: React.MouseEvent, link: FooterLink) => {
    if (link.content) {
      e.preventDefault();
      setActiveContent(link);
    }
  };

  return (
    <footer className="bg-[#050505] text-white pt-16 md:pt-24 mt-20 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 md:gap-24 mb-20">
          <div className="lg:col-span-5 space-y-8">
            <p className="text-neutral-400 text-sm md:text-base leading-relaxed max-w-sm font-medium">
              {description}
            </p>
            {/* Social Icons - Focused on IG, YT, FB, Gmail */}
            <div className="flex flex-wrap items-center gap-8 text-2xl text-neutral-500">
              {socialLinks.instagram && <a href={socialLinks.instagram} target="_blank" className="hover:text-white transition-all transform hover:scale-110 active:scale-95"><i className="fa-brands fa-instagram"></i></a>}
              {socialLinks.youtube && <a href={socialLinks.youtube} target="_blank" className="hover:text-white transition-all transform hover:scale-110 active:scale-95"><i className="fa-brands fa-youtube"></i></a>}
              {socialLinks.facebook && <a href={socialLinks.facebook} target="_blank" className="hover:text-white transition-all transform hover:scale-110 active:scale-95"><i className="fa-brands fa-facebook-f"></i></a>}
              {socialLinks.email && <a href={socialLinks.email} className="hover:text-white transition-all transform hover:scale-110 active:scale-95"><i className="fa-solid fa-envelope"></i></a>}
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4">
            {linkColumns.map((column, colIdx) => (
              <div key={colIdx} className="space-y-6">
                {column.map((link, linkIdx) => (
                  <a 
                    key={linkIdx} 
                    href={link.href} 
                    onClick={(e) => handleLinkClick(e, link)}
                    className="group flex items-center justify-between border-b border-white/5 pb-4 hover:border-indigo-600 transition-all cursor-pointer"
                  >
                    <span className="text-xs font-black tracking-widest group-hover:text-indigo-500 transition-colors uppercase italic">
                      {link.label}
                    </span>
                    <i className={`fa-solid ${link.content ? 'fa-book-open' : 'fa-arrow-up-right'} text-[10px] text-neutral-600 group-hover:text-indigo-500 group-hover:-translate-y-1 group-hover:translate-x-1 transition-all`}></i>
                  </a>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reader Overlay for Link Content */}
      {activeContent && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 md:p-12 bg-black/90 backdrop-blur-3xl animate-in fade-in duration-300">
           <div className="bg-neutral-900 border border-white/10 rounded-[3rem] w-full max-w-2xl overflow-hidden shadow-[0_32px_120px_-12px_rgba(0,0,0,0.8)] animate-in zoom-in-95 duration-200">
              <div className="p-10 md:p-16 space-y-8">
                 <div className="flex justify-between items-center border-b border-white/5 pb-6">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-2xl">
                          <i className="fa-solid fa-book-open text-white"></i>
                       </div>
                       <h2 className="text-2xl font-black uppercase italic tracking-tighter text-white">{activeContent.label}</h2>
                    </div>
                    <button onClick={() => setActiveContent(null)} className="w-10 h-10 rounded-full bg-white/5 hover:bg-rose-500 hover:text-white text-neutral-500 flex items-center justify-center transition-all">
                       <i className="fa-solid fa-xmark"></i>
                    </button>
                 </div>
                 <div className="max-h-[50vh] overflow-y-auto pr-4 hide-scrollbar">
                    <p className="text-neutral-400 text-base md:text-lg font-medium leading-relaxed whitespace-pre-wrap">
                       {activeContent.content}
                    </p>
                 </div>
                 <button onClick={() => setActiveContent(null)} className="w-full bg-white text-black py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all">
                    Return to Hub
                 </button>
              </div>
           </div>
        </div>
      )}

      <div className="relative h-24 md:h-32 bg-black border-t border-white/5 flex items-center overflow-hidden">
        <div className="flex gap-4 px-4 min-w-full animate-marquee-footer">
          {[...cdImages, ...cdImages, ...cdImages].map((img, idx) => (
            <div key={idx} className="relative shrink-0 h-16 md:h-20 aspect-square group">
              <div className="absolute inset-0 bg-neutral-800 rounded-sm border border-white/10 overflow-hidden shadow-2xl">
                <img src={img} className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700" alt="" />
                <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 md:w-10 md:h-10 border-2 border-white/10 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 md:w-3 md:h-3 bg-white/5 rounded-full"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes marquee-footer {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.33%); }
        }
        .animate-marquee-footer {
          animation: marquee-footer 40s linear infinite;
        }
      `}</style>
    </footer>
  );
};

export default Footer;
