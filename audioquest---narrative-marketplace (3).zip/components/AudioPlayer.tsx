
import React, { useState, useRef, useEffect } from 'react';
import { Scene, Book, VisualAsset, TransitionType } from '../types';

interface AudioPlayerProps {
  scene: Scene;
  book: Book;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ scene, book, onClose, onNext, onPrev }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isRepeat, setIsRepeat] = useState(false);
  const [activeAssetIndex, setActiveAssetIndex] = useState(0);
  
  // Audio Controls
  const [isMainMuted, setIsMainMuted] = useState(false);
  const [isAmbientMuted, setIsAmbientMuted] = useState(true); // Default to muted for background sound as requested
  const [assetVolumes, setAssetVolumes] = useState<Record<string, number>>(
    scene.visualAssets.reduce((acc, asset) => ({ ...acc, [asset.id]: 0.5 }), {})
  );

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const visualRefs = useRef<(HTMLVideoElement | HTMLImageElement | null)[]>([]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.load();
      audioRef.current.muted = isMainMuted;
      audioRef.current.play().catch(e => console.log("User interaction required"));
      setIsPlaying(true);
      setActiveAssetIndex(0);
    }
  }, [scene, isMainMuted]);

  // Sync main audio mute
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMainMuted;
    }
  }, [isMainMuted]);

  // Sync asset volumes and master ambient mute to video elements
  useEffect(() => {
    visualRefs.current.forEach((el, idx) => {
      if (el instanceof HTMLVideoElement) {
        const asset = scene.visualAssets[idx];
        if (asset) {
          const assetId = asset.id;
          // Video is muted if master ambient is muted OR if the individual asset was set to muted by creator
          el.muted = isAmbientMuted || asset.isMuted;
          el.volume = assetVolumes[assetId] || 0.5;
          if (isPlaying) el.play().catch(() => {});
        }
      }
    });
  }, [isAmbientMuted, assetVolumes, scene.visualAssets, isPlaying]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) { 
        audioRef.current.pause(); 
        visualRefs.current.forEach(v => {
          if (v instanceof HTMLVideoElement) v.pause();
        });
      } else { 
        audioRef.current.play().catch(() => {}); 
        visualRefs.current.forEach(v => {
          if (v instanceof HTMLVideoElement) v.play().catch(() => {});
        });
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const p = (audioRef.current.currentTime / audioRef.current.duration) * 100;
      setProgress(p || 0);

      const segmentDuration = 8; 
      const newIndex = Math.min(
        Math.floor(audioRef.current.currentTime / segmentDuration),
        scene.visualAssets.length - 1
      );
      if (newIndex !== activeAssetIndex) {
        setActiveAssetIndex(newIndex);
      }
    }
  };

  const handleEnded = () => { 
    if (!isRepeat) { onNext(); } 
    else { 
      if (audioRef.current) {
        audioRef.current.currentTime = 0; 
        audioRef.current.play(); 
      }
    } 
  };

  const handleAssetVolumeChange = (id: string, value: number) => {
    setAssetVolumes(prev => ({ ...prev, [id]: value }));
  };

  const getTransitionClasses = (asset: VisualAsset, isActive: boolean) => {
    const type = asset.transitionType || 'fade';
    const isInstant = type === 'none';
    
    let base = `absolute inset-0 z-0 opacity-0 `;
    
    if (!isInstant) {
      if (type === 'fade') base += 'aq-transition-fade ';
      if (type === 'slide') base += 'aq-transition-slide ';
      if (type === 'zoom') base += 'aq-transition-zoom ';
      if (type === 'blur') base += 'aq-transition-blur ';
    } else {
      base += 'aq-transition-none ';
    }

    if (isActive) {
      base += 'opacity-100 z-10 ';
      if (type === 'slide') base += 'aq-transition-slide-in ';
      if (type === 'zoom') base += 'aq-transition-zoom-in ';
      if (type === 'blur') base += 'aq-transition-blur-in ';
    } else {
      if (type === 'slide') base += 'aq-transition-slide-from ';
      if (type === 'zoom') base += 'aq-transition-zoom-from ';
      if (type === 'blur') base += 'aq-transition-blur-from ';
    }

    return base;
  };

  const activeAsset = scene.visualAssets[activeAssetIndex];

  return (
    <div className="fixed inset-0 z-[100] bg-black animate-in fade-in flex flex-col overflow-hidden">
      
      {/* 1. Cinematic Visual Stage */}
      <div className="flex-1 relative bg-black">
        {scene.visualAssets.map((asset, index) => (
          <div key={asset.id} className={getTransitionClasses(asset, index === activeAssetIndex)}>
            {asset.type === 'video' ? (
              <video 
                ref={el => { visualRefs.current[index] = el; }}
                src={asset.url} 
                loop 
                muted={isAmbientMuted || asset.isMuted} 
                playsInline 
                autoPlay
                className="w-full h-full object-cover"
              />
            ) : (
              <img 
                ref={el => { visualRefs.current[index] = el; }}
                src={asset.url} 
                className="w-full h-full object-cover"
              />
            )}
          </div>
        ))}

        {/* Top Vignette for Controls Visibility */}
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/60 to-transparent z-20 pointer-events-none"></div>

        {/* Global Hub Controls */}
        <div className="absolute top-8 left-8 right-8 z-30 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-2xl">
                <i className="fa-solid fa-headphones text-white"></i>
             </div>
             <div>
                <p className="text-white font-black text-[10px] uppercase tracking-[0.3em] italic">AudioQuest Hub</p>
                <p className="text-neutral-300 text-[8px] font-bold uppercase tracking-widest">Active Narrative Sequence</p>
             </div>
          </div>
          <button onClick={onClose} className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-xl border border-white/20 text-white flex items-center justify-center transition-all">
            <i className="fa-solid fa-xmark text-lg"></i>
          </button>
        </div>

        {/* Individual Clip Volume Sidebar (Right) */}
        {activeAsset && activeAsset.type === 'video' && !isAmbientMuted && !activeAsset.isMuted && (
          <div className="absolute right-8 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center gap-4 group">
             <div className="h-48 w-12 bg-black/40 backdrop-blur-xl border border-white/10 rounded-full flex flex-col items-center justify-center py-6 opacity-0 group-hover:opacity-100 transition-opacity">
                <input 
                   type="range"
                   min="0"
                   max="1"
                   step="0.01"
                   orientation="vertical"
                   value={assetVolumes[activeAsset.id] || 0.5}
                   onChange={(e) => handleAssetVolumeChange(activeAsset.id, parseFloat(e.target.value))}
                   className="h-full w-1 accent-indigo-500 cursor-pointer appearance-none bg-white/20 rounded-full"
                   style={{ WebkitAppearance: 'slider-vertical' } as any}
                />
             </div>
             <div className="w-12 h-12 bg-black/40 backdrop-blur-xl border border-white/10 rounded-full flex items-center justify-center text-white">
                <i className="fa-solid fa-clapperboard text-[10px] text-indigo-400"></i>
             </div>
          </div>
        )}
      </div>

      {/* 2. Floating Narrative & Master Controls */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[90%] max-w-4xl z-40">
        <div className="bg-black/60 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] p-6 md:p-8 shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)] space-y-6">
          
          <audio ref={audioRef} src={scene.audioUrl} onTimeUpdate={handleTimeUpdate} onEnded={handleEnded} />
          
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Narrative Info */}
            <div className="flex-1 text-center md:text-left min-w-0">
               <h2 className="text-white font-black text-xl md:text-2xl uppercase italic tracking-tighter truncate">{scene.title}</h2>
               <div className="flex items-center justify-center md:justify-start gap-2 mt-1">
                 <span className="text-indigo-400 font-black text-[9px] uppercase tracking-widest bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                    {scene.chapterNumber === 0 ? 'Prologue' : `Ch ${scene.chapterNumber}`} • Part {scene.partNumber}
                 </span>
                 <span className="text-neutral-500 font-bold text-[9px] uppercase">Loop {activeAssetIndex + 1}/{scene.visualAssets.length}</span>
               </div>
            </div>

            {/* Primary Transport Controls */}
            <div className="flex items-center gap-3 md:gap-5">
              {/* Master Mute Narration */}
              <button 
                onClick={() => setIsMainMuted(!isMainMuted)} 
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${isMainMuted ? 'bg-rose-500/20 border-rose-500 text-rose-500 shadow-lg shadow-rose-500/20' : 'bg-white/10 border-white/20 text-neutral-400 hover:text-white'}`}
                title="Mute Narration"
              >
                <i className={`fa-solid ${isMainMuted ? 'fa-volume-xmark' : 'fa-volume-high'} text-xs`}></i>
              </button>

              {/* Master Mute Ambient (Videos) - THIS MUTING IS ON BY DEFAULT */}
              <button 
                onClick={() => setIsAmbientMuted(!isAmbientMuted)} 
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${isAmbientMuted ? 'bg-amber-500/20 border-amber-500 text-amber-500 shadow-lg shadow-amber-500/20' : 'bg-indigo-600/20 border-indigo-600 text-indigo-400 hover:text-indigo-300'}`}
                title="Toggle Ambient Sounds (Music on Visuals)"
              >
                <i className={`fa-solid ${isAmbientMuted ? 'fa-music-slash' : 'fa-music'} text-xs`}></i>
              </button>

              <button 
                onClick={() => setIsRepeat(!isRepeat)} 
                className={`text-sm transition-all ${isRepeat ? 'text-indigo-400' : 'text-neutral-500 hover:text-white'}`}
              >
                <i className="fa-solid fa-repeat"></i>
              </button>
              
              <button 
                onClick={togglePlay} 
                className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-all"
              >
                <i className={`fa-solid ${isPlaying ? 'fa-pause' : 'fa-play'} text-lg`}></i>
              </button>
              
              <button 
                onClick={onNext} 
                className="text-neutral-400 hover:text-white text-xl transition-all"
              >
                <i className="fa-solid fa-forward-step"></i>
              </button>
            </div>
          </div>

          {/* Progress Timeline */}
          <div className="space-y-1">
             <div className="flex justify-between text-[8px] font-black uppercase text-neutral-500 tracking-widest px-1">
                <span>{audioRef.current ? Math.floor(audioRef.current.currentTime / 60) + ":" + ("0" + Math.floor(audioRef.current.currentTime % 60)).slice(-2) : "0:00"}</span>
                <span className="text-indigo-500">Live Narrative Sequence</span>
                <span>{scene.duration}</span>
             </div>
             <div className="relative h-1 w-full bg-white/10 rounded-full overflow-hidden group">
                <div 
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-indigo-600 to-indigo-400"
                  style={{ width: `${progress}%` }}
                ></div>
                <input 
                  type="range" 
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  value={progress} 
                  onChange={e => {
                    if (audioRef.current) {
                      const time = (parseFloat(e.target.value) / 100) * audioRef.current.duration;
                      audioRef.current.currentTime = time;
                    }
                  }} 
                />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioPlayer;
