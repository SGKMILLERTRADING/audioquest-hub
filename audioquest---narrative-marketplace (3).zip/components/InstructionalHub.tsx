
import React, { useState, useRef, useEffect } from 'react';
import { User } from '../types';

interface InstructionalHubProps {
  videoUrl: string;
  onUpdate: (newUrl: string) => void;
  onClose: () => void;
  user: User;
}

const InstructionalHub: React.FC<InstructionalHubProps> = ({ videoUrl, onUpdate, onClose, user }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(e => {
        console.log("Autoplay blocked: Manual interaction required for video audio.");
      });
    }
  }, [videoUrl]);

  // Defensive check
  if (!user) return null;
  const isAdmin = user.role === 'admin';

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('video/')) {
        setSelectedFile(file);
      } else {
        alert("Please select a valid video file (MP4, WebM, etc.)");
      }
    }
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedFile) {
      setIsUploading(true);
      setTimeout(() => {
        const localUrl = URL.createObjectURL(selectedFile);
        onUpdate(localUrl);
        setIsUploading(false);
        setShowUploadModal(false);
        setSelectedFile(null);
      }, 1500);
    }
  };

  return (
    <>
      <div className={`fixed bottom-24 right-6 z-[60] transition-all duration-500 ease-in-out ${isMinimized ? 'translate-y-20 scale-75 opacity-50 hover:opacity-100 hover:translate-y-16' : 'translate-y-0 opacity-100'}`}>
        <div className="w-[280px] md:w-[320px] bg-neutral-900/90 backdrop-blur-2xl border border-white/10 rounded-[2rem] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.6)] overflow-hidden ring-1 ring-white/5 group">
          
          {/* Header Controls */}
          <div className="absolute top-3 right-3 z-10 flex gap-2">
            {isAdmin && (
              <button 
                onClick={() => setShowUploadModal(true)}
                className="w-8 h-8 rounded-full bg-indigo-600/80 hover:bg-indigo-600 text-white flex items-center justify-center transition-all shadow-lg shadow-indigo-600/20"
                title="Upload New Instruction (Admin Only)"
              >
                <i className="fa-solid fa-cloud-arrow-up text-[10px]"></i>
              </button>
            )}
            <button 
              onClick={() => setIsMinimized(!isMinimized)}
              className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center transition-all"
              title={isMinimized ? "Expand" : "Minimize"}
            >
              <i className={`fa-solid ${isMinimized ? 'fa-expand' : 'fa-compress'} text-[10px]`}></i>
            </button>
            <button 
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white flex items-center justify-center transition-all shadow-lg shadow-rose-600/20"
              title="Close Tutorial"
            >
              <i className="fa-solid fa-xmark text-[10px]"></i>
            </button>
          </div>

          <div className="relative aspect-video bg-black overflow-hidden">
            <video 
              ref={videoRef}
              src={videoUrl}
              autoPlay
              loop
              muted={isMuted}
              playsInline
              className="w-full h-full object-cover"
              onContextMenu={(e) => e.preventDefault()}
            />
            
            {/* Overlay Info */}
            {!isMinimized && (
              <div className="absolute bottom-3 left-3 flex gap-2">
                <button 
                  onClick={() => setIsMuted(!isMuted)}
                  className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white flex items-center justify-center backdrop-blur-md"
                >
                  <i className={`fa-solid ${isMuted ? 'fa-volume-xmark' : 'fa-volume-high'} text-[10px]`}></i>
                </button>
              </div>
            )}
          </div>

          {!isMinimized && (
            <div className="p-4 bg-gradient-to-t from-neutral-950/80 to-transparent">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shrink-0">
                  <i className="fa-solid fa-graduation-cap text-white text-xs"></i>
                </div>
                <div>
                   <p className="text-[10px] font-black text-white uppercase tracking-tighter italic leading-none">Global Guidance</p>
                   <p className="text-[8px] text-neutral-400 font-bold uppercase tracking-widest mt-1">Direct Native Upload</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Admin Desktop Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] w-full max-md overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 md:p-10 space-y-6">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <i className="fa-solid fa-desktop text-indigo-600"></i>
                  <h2 className="text-xl font-black uppercase italic text-neutral-900 dark:text-white">Desktop Upload</h2>
                </div>
                <button onClick={() => setShowUploadModal(false)} className="text-neutral-400 hover:text-neutral-900 dark:hover:text-white">
                  <i className="fa-solid fa-circle-xmark text-xl"></i>
                </button>
              </div>

              <form onSubmit={handleUploadSubmit} className="space-y-6">
                <input type="file" ref={fileInputRef} className="hidden" accept="video/*" onChange={handleFileChange} />
                <div onClick={() => fileInputRef.current?.click()} className={`border-2 border-dashed rounded-[2rem] p-10 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all ${selectedFile ? 'border-indigo-600 bg-indigo-500/5' : 'border-neutral-200 dark:border-neutral-800 hover:border-indigo-500'}`}>
                  <i className={`fa-solid ${selectedFile ? 'fa-file-video' : 'fa-folder-open'} text-xl text-indigo-600`}></i>
                  <p className="text-xs font-black uppercase tracking-widest">{selectedFile ? selectedFile.name : 'Select Video'}</p>
                </div>
                <button type="submit" disabled={!selectedFile || isUploading} className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-white text-xs uppercase tracking-widest disabled:opacity-30">
                  {isUploading ? 'Processing...' : 'Upload Video'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default InstructionalHub;
