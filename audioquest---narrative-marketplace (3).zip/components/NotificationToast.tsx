
import React from 'react';

interface NotificationToastProps {
  title?: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

const NotificationToast: React.FC<NotificationToastProps> = ({ title, message, type }) => {
  const bgColor = type === 'success' ? 'bg-emerald-500' : type === 'error' ? 'bg-rose-500' : 'bg-indigo-600';
  const icon = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-exclamation' : 'fa-bell';

  return (
    <div className={`${bgColor} text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-right-10 fade-in duration-300 pointer-events-auto border border-white/10 max-w-sm`}>
      <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
        <i className={`fa-solid ${icon}`}></i>
      </div>
      <div>
        {title && <p className="text-[10px] font-black uppercase tracking-widest opacity-90 leading-tight mb-0.5">{title}</p>}
        <p className="text-[11px] font-bold uppercase tracking-wide leading-tight">{message}</p>
      </div>
    </div>
  );
};

export default NotificationToast;
