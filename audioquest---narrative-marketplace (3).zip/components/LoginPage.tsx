
import React, { useState } from 'react';

interface LoginPageProps {
  onLogin: (role: 'admin' | 'user', username?: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [isSimulating, setIsSimulating] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsSimulating(true);
    setError('');

    // In a real Supabase app, this would be: 
    // const { user, error } = await supabase.auth.signIn({ email, password });
    setTimeout(() => {
      setIsSimulating(false);
      const isAdmin = (email === 'sgkmillertrading@gmail.com' && password === 'Chinsher1') || 
                      (email.toLowerCase().includes('creatorjm'));
      
      const username = email.toLowerCase().includes('creatorjm') ? 'CreatorJM' : (isAdmin ? 'AdminCreator' : email.split('@')[0]);

      if (isAdmin) {
        onLogin('admin', username);
      } else if (email.includes('@') && password.length >= 6) {
        onLogin('user', username);
      } else {
        setError('Minimum 6 characters required for password.');
      }
    }, 1200);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-neutral-950">
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-indigo-600 rounded-full blur-[140px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-emerald-600 rounded-full blur-[140px] opacity-30"></div>
      </div>

      <div className="relative z-10 w-full max-w-md px-6 animate-in fade-in zoom-in duration-700">
        <div className="glass-card p-12 rounded-[3.5rem] border border-white/10 shadow-2xl text-center space-y-10">
          <div className="space-y-4">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/30">
              <i className="fa-solid fa-headphones text-3xl text-white"></i>
            </div>
            <h1 className="text-3xl font-black text-white uppercase italic tracking-tighter">AudioQuest Hub</h1>
            <p className="text-neutral-400 text-xs font-bold uppercase tracking-widest italic opacity-70">The World's Narrative Marketplace</p>
          </div>

          <div className="space-y-4">
             <button onClick={() => setShowPopup(true)} className="w-full flex items-center justify-center gap-4 bg-white hover:bg-neutral-100 text-black py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl transition-all">
                <i className="fa-brands fa-google text-lg text-rose-500"></i>
                Continue with Google
             </button>
             <div className="flex items-center gap-4 py-2 opacity-30">
                <div className="h-px bg-white flex-1"></div>
                <span className="text-[10px] text-white font-black">OR</span>
                <div className="h-px bg-white flex-1"></div>
             </div>
             <button onClick={() => setShowPopup(true)} className="w-full border border-white/20 hover:bg-white/5 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all">
                Email Sign In / Sign Up
             </button>
          </div>

          <div className="flex items-center justify-center gap-2">
            <img src="https://supabase.com/dashboard/img/supabase-logo.svg" className="w-4 h-4 opacity-50" alt="Supabase Auth Ready" />
            <p className="text-[8px] text-neutral-500 font-black uppercase tracking-widest">Supabase Auth Bridge Ready</p>
          </div>
        </div>
      </div>

      {showPopup && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white dark:bg-neutral-900 rounded-[3rem] w-full max-w-[420px] overflow-hidden shadow-2xl p-10 space-y-8 border border-neutral-200 dark:border-neutral-800">
             <div className="text-center space-y-2">
                <h2 className="text-2xl font-black text-neutral-900 dark:text-white uppercase italic tracking-tighter">Identity Sync</h2>
                <p className="text-neutral-500 dark:text-neutral-400 text-[10px] font-black uppercase tracking-widest">Permanent Cloud Login</p>
             </div>
             <form onSubmit={handleAuth} className="space-y-6">
                <div className="space-y-3">
                   <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase tracking-widest text-neutral-400 ml-2">Email Address</label>
                      <input 
                        type="email" 
                        placeholder="e.g. CreatorJM@hub.com" 
                        value={email} 
                        onChange={e => setEmail(e.target.value)} 
                        className="w-full bg-neutral-50 dark:bg-neutral-800 border-2 border-neutral-200 dark:border-neutral-700 rounded-2xl px-6 py-4 font-black text-neutral-900 dark:text-white placeholder:text-neutral-300 dark:placeholder:text-neutral-600 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/10 transition-all text-sm" 
                        required 
                      />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[8px] font-black uppercase tracking-widest text-neutral-400 ml-2">Secure Passcode</label>
                      <input 
                        type="password" 
                        placeholder="••••••••" 
                        value={password} 
                        onChange={e => setPassword(e.target.value)} 
                        className="w-full bg-neutral-50 dark:bg-neutral-800 border-2 border-neutral-200 dark:border-neutral-700 rounded-2xl px-6 py-4 font-black text-neutral-900 dark:text-white placeholder:text-neutral-300 dark:placeholder:text-neutral-600 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/10 transition-all text-sm" 
                        required 
                      />
                   </div>
                   {error && <p className="text-rose-600 text-[9px] font-black uppercase tracking-widest px-2">{error}</p>}
                </div>
                <button type="submit" disabled={isSimulating} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-5 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl transition-all active:scale-95 disabled:opacity-50">
                   {isSimulating ? <i className="fa-solid fa-spinner animate-spin mr-2"></i> : null}
                   {isSimulating ? 'Authenticating...' : 'Authorize Access'}
                </button>
                <button type="button" onClick={() => setShowPopup(false)} className="w-full text-neutral-400 font-black text-[10px] uppercase tracking-widest hover:text-neutral-600 transition-colors">Back</button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginPage;
