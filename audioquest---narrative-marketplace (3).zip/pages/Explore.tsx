
import React, { useState, useMemo } from 'react';
import { Book, Page } from '../types';
import { CATEGORIES } from '../constants';

interface ExploreProps {
  books: Book[];
  onSelectBook: (book: Book) => void;
  onNavigate: (page: Page) => void;
}

const Explore: React.FC<ExploreProps> = ({ books, onSelectBook, onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredBooks = useMemo(() => {
    return books.filter(book => {
      const matchesCategory = selectedCategory === 'All' || book.category === selectedCategory;
      const matchesSearch = book.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            book.authorName.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [books, selectedCategory, searchQuery]);

  return (
    <div className="space-y-10 pb-32 max-w-7xl mx-auto theme-transition">
      {/* Search and Header Section */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-4xl md:text-5xl font-black text-neutral-900 dark:text-white uppercase italic tracking-tighter leading-none">
              Explore the <span className="text-indigo-600">Hub</span>
            </h1>
            <p className="text-neutral-500 dark:text-neutral-400 font-bold uppercase tracking-widest text-[10px]">
              Discover narratives from creators worldwide
            </p>
          </div>
          
          <div className="w-full md:w-96 relative">
            <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400"></i>
            <input 
              type="text"
              placeholder="Filter by title or author..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:outline-none focus:border-indigo-600 shadow-sm transition-all dark:text-white"
            />
          </div>
        </div>

        {/* Category Filter Bar */}
        <div className="flex gap-2 overflow-x-auto pb-4 hide-scrollbar -mx-4 px-4">
          <button 
            onClick={() => setSelectedCategory('All')}
            className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
              selectedCategory === 'All' 
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20' 
              : 'bg-white dark:bg-neutral-900 text-neutral-500 border-neutral-200 dark:border-neutral-800 hover:border-indigo-600'
            }`}
          >
            All Genres
          </button>
          {CATEGORIES.map(cat => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap border ${
                selectedCategory === cat 
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20' 
                : 'bg-white dark:bg-neutral-900 text-neutral-500 border-neutral-200 dark:border-neutral-800 hover:border-indigo-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Grid */}
      {filteredBooks.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 md:gap-8">
          {filteredBooks.map(book => (
            <div 
              key={book.id} 
              className="group cursor-pointer space-y-3"
              onClick={() => onSelectBook(book)}
            >
              <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-xl border border-neutral-200 dark:border-white/5 bg-neutral-200 dark:bg-neutral-900">
                <img 
                  src={book.coverImage} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                  alt={book.title} 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end">
                  <span className="text-[8px] font-black bg-indigo-600 text-white px-3 py-1 rounded-full uppercase self-start mb-2">
                    {book.category}
                  </span>
                </div>
                <div className="absolute top-3 right-3 bg-white/90 dark:bg-neutral-950/80 backdrop-blur-md px-2 py-1 rounded-lg flex items-center gap-1 border border-neutral-200 dark:border-white/10 shadow-lg">
                  <i className="fa-solid fa-star text-amber-500 text-[8px]"></i>
                  <span className="text-[10px] font-black text-neutral-900 dark:text-white">{book.averageRating}</span>
                </div>
              </div>
              
              <div className="space-y-1">
                <h3 className="font-bold text-sm md:text-base line-clamp-1 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors text-neutral-900 dark:text-white uppercase tracking-tight">
                  {book.title}
                </h3>
                <p className="text-[10px] text-neutral-500 font-black uppercase tracking-widest truncate">
                  By <span className="text-indigo-600 italic">{book.authorName}</span>
                </p>
                <div className="flex items-center gap-2 pt-1">
                   <span className="text-[9px] font-black text-neutral-400 uppercase">{book.totalChapters} CHAPTERS</span>
                   <span className="text-neutral-300 dark:text-neutral-800">•</span>
                   <span className="text-[9px] font-black text-amber-500 uppercase">{book.listenerCount} FANS</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-32 text-center space-y-4">
           <div className="w-20 h-20 bg-neutral-100 dark:bg-neutral-900 rounded-full flex items-center justify-center mx-auto text-neutral-300 dark:text-neutral-700">
              <i className="fa-solid fa-book-open-reader text-4xl"></i>
           </div>
           <div className="space-y-1">
             <h3 className="text-xl font-black text-neutral-900 dark:text-white uppercase italic">No Hubs Found</h3>
             <p className="text-neutral-500 text-xs font-bold uppercase tracking-widest">Try adjusting your filters or search query.</p>
           </div>
           <button 
            onClick={() => {setSelectedCategory('All'); setSearchQuery('');}}
            className="text-indigo-600 font-black text-[10px] uppercase tracking-widest hover:underline"
           >
             Clear all filters
           </button>
        </div>
      )}
    </div>
  );
};

export default Explore;
