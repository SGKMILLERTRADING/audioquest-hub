
import React, { useState, useEffect } from 'react';
import { User, PayoutInfo, FooterLink, SaleConfig, SocialLinks } from '../types';

interface WalletProps {
  user: User;
  onUpdatePayout: (info: PayoutInfo) => void;
  onUpdateProfile: (username: string, avatar: string) => void;
  onGiftCoins: (username: string, amount: number) => void;
  categories: string[];
  onUpdateCategories: (categories: string[]) => void;
  footerLinks: FooterLink[][];
  onUpdateFooterLinks: (links: FooterLink[][]) => void;
  heroContent: {
    titlePrefix: string;
    titleHighlight: string;
    description: string;
    backgroundImage: string;
    primaryButton: string;
    secondaryButton: string;
  };
  onUpdateHero: (content: any) => void;
  announcement: string;
  onUpdateAnnouncement: (text: string) => void;
  promoBanner: {
    title: string;
    subtitle: string;
    cta: string;
    bgImage: string;
  };
  onUpdatePromoBanner: (content: any) => void;
  saleConfig: SaleConfig;
  onUpdateSaleConfig: (config: SaleConfig) => void;
  footerDescription: string;
  onUpdateFooterDescription: (desc: string) => void;
  socialLinks: SocialLinks;
  onUpdateSocialLinks: (socials: SocialLinks) => void;
  footerCdImages: string[];
  onUpdateFooterCdImages: (imgs: string[]) => void;
  onUpdateStripe: (key: string) => void;
}

const Wallet: React.FC<WalletProps> = (props) => {
  const { 
    user, onUpdatePayout, onGiftCoins, heroContent, onUpdateHero, announcement, 
    onUpdateAnnouncement, categories, onUpdateCategories, promoBanner, onUpdatePromoBanner,
    saleConfig, onUpdateSaleConfig, footerDescription, onUpdateFooterDescription,
    socialLinks, onUpdateSocialLinks, footerCdImages, onUpdateFooterCdImages,
    footerLinks, onUpdateFooterLinks, onUpdateProfile, onUpdateStripe
  } = props;

  const [activeTab, setActiveTab] = useState<'earnings' | 'admin'>('earnings');
  const [adminSubTab, setAdminSubTab] = useState<'branding' | 'ecosystem' | 'api' | 'launch'>('launch');
  const [sqlExecuted, setSqlExecuted] = useState(false);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [stripeKeyInput, setStripeKeyInput] = useState(user.stripeKey || '');

  const [supabaseCreds, setSupabaseCreds] = useState({ 
    url: '', 
    key: '', 
    projectId: 'falvrfjeexwvcjpaggbj' 
  });

  const [localHero, setLocalHero] = useState({...heroContent});

  useEffect(() => {
    setLocalHero({...heroContent});
  }, [heroContent]);

  const supabaseSQL = `-- AudioQuest Narrative Hub Schema
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE,
  username TEXT UNIQUE,
  avatar_url TEXT,
  coins INTEGER DEFAULT 100,
  earnings DECIMAL DEFAULT 0,
  role TEXT DEFAULT 'user',
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS books (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  author_id UUID REFERENCES profiles(id),
  title TEXT NOT NULL,
  description TEXT,
  cover_image TEXT,
  category TEXT,
  average_rating DECIMAL DEFAULT 0,
  listener_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS scenes (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  book_id UUID REFERENCES books(id) ON DELETE CASCADE,
  title TEXT,
  audio_url TEXT,
  cost INTEGER DEFAULT 15,
  chapter_number INTEGER,
  part_number INTEGER,
  scene_number INTEGER
);`;

  const handleStripeVerify = () => {
    const key = stripeKeyInput.trim();
    if (!key) return alert("Please enter your Publishable Key.");
    if (!key.startsWith('pk_')) return alert("Invalid Format: Key must start with 'pk_'.");
    onUpdateStripe(key);
    const mode = key.startsWith('pk_live_') ? "LIVE PRODUCTION" : "SANDBOX TEST";
    alert(`Stripe Gateway Synchronized! Current Mode: ${mode}.`);
  };

  if (!user) return null;

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-32 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 bg-white dark:bg-neutral-900/50 p-8 rounded-[3rem] border border-neutral-200 dark:border-neutral-800 shadow-2xl">
        <div className="flex items-center gap-6">
           <img src={user.avatar} className="w-20 h-20 rounded-full border-4 border-indigo-600 shadow-xl" alt="User" />
           <div>
              <h1 className="text-4xl font-black text-neutral-900 dark:text-white uppercase italic tracking-tighter leading-none">{user.username}</h1>
              <p className="text-neutral-500 font-bold uppercase text-[10px] tracking-widest mt-1">Status: {user.role === 'admin' ? 'Master Admin' : 'Creator'}</p>
           </div>
        </div>
        <div className="flex bg-neutral-100 dark:bg-neutral-800 p-1 rounded-2xl border border-neutral-200 dark:border-neutral-700">
           <button onClick={() => setActiveTab('earnings')} className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${activeTab === 'earnings' ? 'bg-indigo-600 text-white shadow-lg' : 'text-neutral-500 hover:text-indigo-500'}`}>Earnings Hub</button>
           {user.role === 'admin' && (
             <button onClick={() => setActiveTab('admin')} className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase transition-all ${activeTab === 'admin' ? 'bg-indigo-600 text-white shadow-lg' : 'text-neutral-500 hover:text-indigo-500'}`}>Command Center</button>
           )}
        </div>
      </div>

      {activeTab === 'earnings' ? (
        <div className="space-y-10 animate-in fade-in">
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 p-8 rounded-[2.5rem] shadow-xl">
                 <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-2 italic">Creator Earnings</p>
                 <h2 className="text-5xl font-black text-emerald-500 italic tracking-tighter">${(user.earnings || 0).toFixed(2)}</h2>
                 <p className="text-[8px] text-neutral-500 font-black uppercase mt-2">Personal Share from Narratives</p>
              </div>
              {user.role === 'admin' && (
                <div className="bg-indigo-600/5 border border-indigo-600/20 p-8 rounded-[2.5rem] shadow-xl">
                   <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-2 italic">Platform Treasury</p>
                   <h2 className="text-5xl font-black text-indigo-600 italic tracking-tighter">${(user.platformRevenue || 0).toFixed(2)}</h2>
                   <p className="text-[8px] text-indigo-500/70 font-black uppercase mt-2">Total Cash from Coin Purchases</p>
                </div>
              )}
              <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 p-8 rounded-[2.5rem] shadow-xl">
                 <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-2 italic">Active Coins</p>
                 <h2 className="text-5xl font-black text-amber-500 italic tracking-tighter">{user.coins || 0}</h2>
              </div>
           </div>
        </div>
      ) : (
        <div className="space-y-12">
           <div className="flex gap-4 border-b border-neutral-200 dark:border-neutral-800 pb-2 overflow-x-auto hide-scrollbar">
              <button onClick={() => setAdminSubTab('launch')} className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest transition-all ${adminSubTab === 'launch' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-neutral-400'}`}>Launch Checklist</button>
              <button onClick={() => setAdminSubTab('api')} className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest transition-all ${adminSubTab === 'api' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-neutral-400'}`}>Cloud Bridge (API)</button>
              <button onClick={() => setAdminSubTab('branding')} className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest transition-all ${adminSubTab === 'branding' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-neutral-400'}`}>Branding & UI</button>
           </div>

           {adminSubTab === 'launch' && (
             <div className="space-y-8 animate-in slide-in-from-bottom-4">
                <div className="bg-neutral-900 rounded-[3rem] p-12 border border-white/5 space-y-10 shadow-2xl">
                   <div className="space-y-2">
                      <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">Production Launch Roadmap</h3>
                      <p className="text-neutral-500 font-bold uppercase text-[10px] tracking-widest">Follow these steps to take your app from demo to live business</p>
                   </div>
                   
                   <div className="grid gap-6">
                      {[
                        { step: 1, title: 'Download Source Code', desc: 'Copy all files (App.tsx, etc.) and save them to a project folder on your computer.', icon: 'fa-download', color: 'text-indigo-500' },
                        { step: 2, title: 'Host on Vercel', desc: 'Upload your folder to Vercel.com. It will give you a live URL like audioquest-hub.vercel.app.', icon: 'fa-cloud-arrow-up', color: 'text-sky-500' },
                        { step: 3, title: 'Initialize Supabase', desc: 'Go to Supabase.com, create a project, and run the SQL code in the "API" tab to create your tables.', icon: 'fa-database', color: 'text-emerald-500' },
                        { step: 4, title: 'Switch to Live Stripe', desc: 'Once your store works in Test Mode, swap your Test Key for your Live Key in the "API" tab.', icon: 'fa-money-bill-transfer', color: 'text-amber-500' }
                      ].map(item => (
                        <div key={item.step} className="flex gap-6 items-start bg-white/5 p-6 rounded-3xl border border-white/5 hover:bg-white/10 transition-all">
                           <div className={`w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center ${item.color} text-xl shrink-0`}>
                              <i className={`fa-solid ${item.icon}`}></i>
                           </div>
                           <div className="space-y-1">
                              <h4 className="text-sm font-black text-white uppercase italic tracking-tight">Step {item.step}: {item.title}</h4>
                              <p className="text-neutral-400 text-xs font-medium">{item.desc}</p>
                           </div>
                        </div>
                      ))}
                   </div>

                   <div className="p-8 bg-indigo-600 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-indigo-600/20">
                      <div className="space-y-2 text-center md:text-left">
                        <h4 className="text-white font-black text-xl uppercase italic tracking-tighter">Ready to take the first step?</h4>
                        <p className="text-white/80 text-[10px] font-black uppercase tracking-widest">Your Narrative Empire starts here.</p>
                      </div>
                      <button onClick={() => setAdminSubTab('api')} className="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:scale-105 transition-all">Setup API Bridge</button>
                   </div>
                </div>
             </div>
           )}

           {adminSubTab === 'api' && (
             <div className="space-y-10 animate-in slide-in-from-bottom-4">
                <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] p-10 shadow-xl space-y-8">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg" className="h-6" alt="Stripe" />
                        <h3 className="font-black text-xl uppercase tracking-tighter text-indigo-600 italic">Global API Identity</h3>
                      </div>
                      {user.stripeKey && (
                        <span className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest flex items-center gap-2 ${user.stripeKey.startsWith('pk_live') ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                           <i className="fa-solid fa-circle-check"></i> {user.stripeKey.startsWith('pk_live') ? 'Live Mode' : 'Test Mode'}
                        </span>
                      )}
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                      <div className="md:col-span-7 space-y-6">
                        <div className="space-y-1">
                          <label className="text-[8px] font-black uppercase text-neutral-400 px-2 flex justify-between">
                             Stripe Publishable Key
                             <a href="https://dashboard.stripe.com/apikeys" target="_blank" className="text-indigo-500 hover:underline">Open Dashboard</a>
                          </label>
                          <input 
                            type="password" 
                            placeholder="pk_test_..." 
                            value={stripeKeyInput}
                            onChange={e => setStripeKeyInput(e.target.value)}
                            className="w-full bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-4 text-[10px] font-mono focus:border-indigo-500 outline-none transition-all" 
                          />
                        </div>
                        <button onClick={handleStripeVerify} className="w-full py-5 rounded-2xl bg-indigo-600 text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-600/30 hover:bg-indigo-500 transition-all">Verify & Sync Gateway</button>
                      </div>
                      <div className="md:col-span-5">
                         <div className="bg-neutral-900 rounded-[2.5rem] p-8 border border-white/5 space-y-6">
                            <h4 className="text-[10px] font-black uppercase text-white/40 tracking-widest italic">Connection Status</h4>
                            <div className="space-y-4">
                               <div className="flex justify-between items-center border-b border-white/5 pb-3"><span className="text-[10px] font-black text-neutral-400 uppercase">Stripe Bridge</span><span className={`text-[10px] font-black uppercase ${user.stripeKey ? 'text-emerald-500' : 'text-neutral-600'}`}>{user.stripeKey ? 'Active' : 'Disconnected'}</span></div>
                               <div className="flex justify-between items-center border-b border-white/5 pb-3"><span className="text-[10px] font-black text-neutral-400 uppercase">Real Revenue</span><span className="text-[10px] font-black text-rose-500 uppercase">{user.stripeKey?.startsWith('pk_live') ? 'Armed' : 'Inactive'}</span></div>
                               <div className="flex justify-between items-center"><span className="text-[10px] font-black text-neutral-400 uppercase">Secure Hub</span><i className="fa-solid fa-shield-halved text-emerald-500 text-xs"></i></div>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>

                <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] p-10 shadow-xl space-y-6">
                   <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-4 gap-4">
                      <div>
                        <h4 className="text-xs font-black uppercase text-neutral-900 dark:text-white italic tracking-tighter leading-none">Supabase Database Blueprint</h4>
                        <p className="text-[8px] text-neutral-400 font-bold uppercase tracking-widest mt-1">Copy this code and run it in your Supabase SQL Editor.</p>
                      </div>
                      <button onClick={() => {navigator.clipboard.writeText(supabaseSQL); alert("SQL Blueprint Copied!");}} className="bg-indigo-600 text-white px-6 py-2 rounded-xl text-[8px] font-black uppercase tracking-widest shadow-lg hover:bg-indigo-500 transition-all">Copy SQL Code</button>
                   </div>
                   <div className="bg-neutral-950 p-8 rounded-3xl border border-white/5 relative h-[250px] overflow-hidden">
                      <pre className="text-[10px] font-mono text-emerald-400/60 h-full overflow-y-auto leading-relaxed custom-scrollbar whitespace-pre-wrap">{supabaseSQL}</pre>
                   </div>
                </div>
             </div>
           )}

           {adminSubTab === 'branding' && (
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in slide-in-from-bottom-4">
                <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] p-10 shadow-xl space-y-8">
                   <h3 className="font-black text-xs uppercase tracking-widest text-indigo-600 italic">Cinematic UI Control</h3>
                   <div className="space-y-6">
                      <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 px-2">Hero Title Prefix</label><input type="text" value={localHero.titlePrefix} onChange={e => {const updated = {...localHero, titlePrefix: e.target.value}; setLocalHero(updated); onUpdateHero(updated);}} className="w-full bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-[10px] font-black uppercase" /></div>
                      <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 px-2">Hero Highlight Text</label><input type="text" value={localHero.titleHighlight} onChange={e => {const updated = {...localHero, titleHighlight: e.target.value}; setLocalHero(updated); onUpdateHero(updated);}} className="w-full bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-[10px] font-black uppercase text-indigo-600" /></div>
                      <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 px-2">Marquee Announcement Bar</label><input type="text" value={announcement} onChange={e => onUpdateAnnouncement(e.target.value)} className="w-full bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-[10px] font-black uppercase italic" /></div>
                   </div>
                </div>
                <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] p-10 shadow-xl space-y-8">
                   <h3 className="font-black text-xs uppercase tracking-widest text-indigo-600 italic">Hero Narrative</h3>
                   <div className="space-y-4">
                      <textarea value={localHero.description} onChange={e => {const updated = {...localHero, description: e.target.value}; setLocalHero(updated); onUpdateHero(updated);}} rows={5} className="w-full bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-2xl px-5 py-4 text-xs font-medium italic resize-none" />
                   </div>
                </div>
             </div>
           )}
        </div>
      )}
    </div>
  );
};

export default Wallet;
