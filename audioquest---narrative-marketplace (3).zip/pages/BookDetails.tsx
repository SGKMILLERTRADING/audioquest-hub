
import React, { useState, useMemo } from 'react';
import { Book, Scene, User } from '../types';

interface BookDetailsProps {
  book: Book;
  scenes: Scene[];
  user: User;
  onPlay: (scene: Scene) => void;
  onPurchase: (scene: Scene) => void;
}

type SortKey = 'chapterNumber' | 'partNumber' | 'sceneNumber';

const BookDetails: React.FC<BookDetailsProps> = ({ book, scenes, user, onPlay, onPurchase }) => {
  const [unlockedScenes, setUnlockedScenes] = useState<string[]>([]);
  const [expandedChapter, setExpandedChapter] = useState<number | null>(0);
  const [sortKey, setSortKey] = useState<SortKey>('sceneNumber');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const structure = useMemo(() => {
    const sortedScenes = [...scenes].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (valA !== valB) return sortOrder === 'asc' ? valA - valB : valB - valA;
      return a.sceneNumber - b.sceneNumber;
    });

    const chapters: Record<number, Record<number, Scene[]>> = {};
    sortedScenes.forEach(scene => {
      if (!chapters[scene.chapterNumber]) chapters[scene.chapterNumber] = {};
      if (!chapters[scene.chapterNumber][scene.partNumber]) chapters[scene.chapterNumber][scene.partNumber] = [];
      chapters[scene.chapterNumber][scene.partNumber].push(scene);
    });
    
    return Object.keys(chapters).map(Number).sort((a, b) => sortOrder === 'asc' ? a - b : b - a).map(chNum => ({
      number: chNum,
      label: chNum === 0 ? 'Prologue' : `Chapter ${chNum}`,
      parts: Object.keys(chapters[chNum]).map(Number).sort((a, b) => sortOrder === 'asc' ? a - b : b - a).map(ptNum => ({
        number: ptNum,
        scenes: chapters[chNum][ptNum]
      }))
    }));
  }, [scenes, sortKey, sortOrder]);

  const handleAction = (scene: Scene) => {
    // Admin bypass: CreatorJM can listen to anything
    const isFree = scene.chapterNumber === 0 && scene.sceneNumber <= 2;
    if (user.role === 'admin' || unlockedScenes.includes(scene.id) || isFree) {
      onPlay(scene);
    } else {
      const cost = scene.cost || 15;
      if (user.coins >= cost) {
        if (confirm(`Unlock Scene ${scene.sceneNumber} for ${cost} coins?`)) {
          setUnlockedScenes([...unlockedScenes, scene.id]);
          onPurchase(scene);
        }
      } else {
        alert("Not enough coins! Visit the Store to top up.");
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-20 theme-transition">
      <div className="flex flex-col md:flex-row gap-12">
        <div className="w-full md:w-2/5 shrink-0"><img src={book.coverImage} className="w-full aspect-[3/4] object-cover rounded-[3rem] shadow-2xl border border-neutral-200 dark:border-neutral-800" alt={book.title} /></div>
        <div className="flex-1 space-y-6">
          <div className="space-y-3">
            <span className="bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 px-4 py-1.5 rounded-full text-[10px] font-black uppercase border border-indigo-500/20 tracking-widest">{book.category}</span>
            <h1 className="text-5xl font-black text-neutral-900 dark:text-white uppercase italic tracking-tighter leading-none">{book.title}</h1>
            <p className="text-2xl text-neutral-500">By <span className="text-indigo-600 font-black italic">{book.authorName}</span></p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] p-6 text-center shadow-lg"><p className="text-[10px] text-neutral-400 font-black uppercase mb-1 tracking-widest">Listener Count</p><p className="font-black text-indigo-600 text-3xl italic">{book.listenerCount}</p></div>
            <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] p-6 text-center shadow-lg"><p className="text-[10px] text-neutral-400 font-black uppercase mb-1 tracking-widest">Hub Rating</p><p className="font-black text-amber-500 text-3xl italic">{book.averageRating} <i className="fa-solid fa-star text-base"></i></p></div>
          </div>
          <div className="bg-neutral-50 dark:bg-neutral-900 p-8 rounded-[2rem] border border-neutral-200 dark:border-neutral-800 shadow-sm"><p className="text-neutral-600 dark:text-neutral-400 italic font-medium">"{book.description}"</p></div>
        </div>
      </div>

      <div className="space-y-8 pt-10 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h2 className="text-2xl font-black text-neutral-900 dark:text-white uppercase italic tracking-tighter">Narrative Sequences</h2>
          <div className="flex items-center gap-4 bg-neutral-100 dark:bg-neutral-900 px-5 py-2.5 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-inner">
             <select value={sortKey} onChange={e => setSortKey(e.target.value as SortKey)} className="bg-transparent text-[10px] font-black uppercase outline-none cursor-pointer tracking-widest text-neutral-600 dark:text-neutral-400">
                <option value="sceneNumber">Sort: Scene</option>
                <option value="partNumber">Sort: Part</option>
                <option value="chapterNumber">Sort: Chapter</option>
             </select>
             <button onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')} className="text-indigo-600 hover:text-indigo-400 transition-colors">
               <i className={`fa-solid ${sortOrder === 'asc' ? 'fa-arrow-down-1-9' : 'fa-arrow-up-9-1'} text-sm`}></i>
             </button>
          </div>
        </div>
        
        <div className="space-y-4">
          {structure.map(chapter => (
            <div key={chapter.number} className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] overflow-hidden shadow-md group">
              <button onClick={() => setExpandedChapter(expandedChapter === chapter.number ? null : chapter.number)} className={`w-full px-8 py-6 flex items-center justify-between transition-colors ${expandedChapter === chapter.number ? 'bg-indigo-600/5' : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/50'}`}>
                <h3 className="text-lg font-black uppercase italic text-neutral-900 dark:text-white tracking-tight">{chapter.label}</h3>
                <i className={`fa-solid fa-chevron-down transition-transform duration-300 ${expandedChapter === chapter.number ? 'rotate-180 text-indigo-600' : 'text-neutral-400'}`}></i>
              </button>
              {expandedChapter === chapter.number && (
                <div className="px-8 pb-8 animate-in slide-in-from-top-4 duration-300">
                  {chapter.parts.map(part => (
                    <div key={part.number} className="mt-8 first:mt-4 last:mb-0">
                      <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest mb-4 italic">Sequence: Part {part.number}</p>
                      <div className="grid gap-3">
                        {part.scenes.map(scene => {
                          const isFree = (scene.chapterNumber === 0 && scene.sceneNumber <= 2);
                          const isUnlocked = user.role === 'admin' || unlockedScenes.includes(scene.id) || isFree;
                          return (
                            <div key={scene.id} onClick={() => handleAction(scene)} className={`group/scene flex items-center justify-between p-5 rounded-2xl border transition-all cursor-pointer ${isUnlocked ? 'bg-neutral-50 dark:bg-neutral-800/30 border-neutral-200 dark:border-neutral-800 hover:border-indigo-500' : 'opacity-70 border-neutral-100 dark:border-neutral-900 grayscale hover:grayscale-0'}`}>
                              <div className="flex items-center gap-5">
                                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${isUnlocked ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-400 group-hover/scene:bg-indigo-600 group-hover/scene:text-white'}`}>
                                  {isUnlocked ? <i className="fa-solid fa-play text-xs"></i> : <i className="fa-solid fa-lock text-xs"></i>}
                                </div>
                                <div className="space-y-0.5">
                                   <h4 className={`font-black text-sm uppercase tracking-tight italic ${isUnlocked ? 'text-neutral-900 dark:text-white' : 'text-neutral-500'}`}>Scene {scene.sceneNumber}: {scene.title}</h4>
                                   <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest">{scene.duration} • {scene.uploadDate}</p>
                                </div>
                              </div>
                              {!isUnlocked && <div className="flex items-center gap-2 bg-amber-500/10 text-amber-600 px-4 py-1.5 rounded-full border border-amber-500/20 shadow-sm"><i className="fa-solid fa-coins text-[9px]"></i><span className="text-[10px] font-black uppercase tracking-widest">{scene.cost} Coins</span></div>}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BookDetails;
