
import React, { useRef } from 'react';
import { Book, Page, User, SaleConfig, Scene } from '../types';

interface HomeProps {
  books: Book[];
  latestScenes: { scene: Scene, book: Book }[];
  onSelectBook: (book: Book) => void;
  onNavigate: (page: Page) => void;
  heroContent: {
    titlePrefix: string;
    titleHighlight: string;
    description: string;
    backgroundImage: string;
    primaryButton: string;
    secondaryButton: string;
  };
  promoBanner: {
    title: string;
    subtitle: string;
    cta: string;
    bgImage: string;
  };
  user: User;
  saleConfig: SaleConfig;
  onUpdateHeroImage: (url: string) => void;
  onUpdatePromoBanner: (content: any) => void;
}

const Home: React.FC<HomeProps> = ({ books, latestScenes, onSelectBook, onNavigate, heroContent, promoBanner, user, saleConfig, onUpdateHeroImage, onUpdatePromoBanner }) => {
  const trendingThisWeek = [...books].sort((a, b) => b.listenerCount - a.listenerCount).slice(0, 8);
  const popularOnAQ = [...books].filter(b => b.averageRating > 4.6).slice(0, 6);
  const recentlyPlayedBooks = books.filter(b => user.recentlyPlayed?.includes(b.id));
  
  const heroFileInputRef = useRef<HTMLInputElement>(null);
  const promoFileInputRef = useRef<HTMLInputElement>(null);

  const handleHeroUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onUpdateHeroImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handlePromoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onUpdatePromoBanner({ ...promoBanner, bgImage: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const Section = ({ title, books, icon, color = 'text-indigo-500' }: { title: string, books: Book[], icon?: string, color?: string }) => {
    if (books.length === 0) return null;
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between px-2">
          <h2 className="text-xl md:text-2xl font-black flex items-center gap-3 tracking-tight text-neutral-900 dark:text-white uppercase italic">
            {icon && <i className={`fa-solid ${icon} ${color}`}></i>}
            {title}
          </h2>
          <button onClick={() => onNavigate(Page.EXPLORE)} className="text-[10px] font-black uppercase text-neutral-400 dark:text-neutral-500 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors tracking-widest">See More</button>
        </div>
        <div className="flex gap-4 md:gap-6 overflow-x-auto pb-6 hide-scrollbar px-2 -mx-2 snap-x">
          {books.map(book => (
            <div key={book.id} className="snap-start shrink-0 w-[160px] md:w-[220px] group cursor-pointer" onClick={() => onSelectBook(book)}>
              <div className="relative aspect-[3/4] rounded-2xl overflow-hidden mb-3 shadow-xl border border-neutral-200 dark:border-white/5 bg-neutral-200 dark:bg-neutral-900 transition-all group-hover:shadow-indigo-500/10">
                <img src={book.coverImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-95 group-hover:opacity-100" alt={book.title} />
                <div className="absolute top-2 right-2 flex flex-col gap-1 z-10">
                   <div className="bg-white/90 dark:bg-neutral-950/80 backdrop-blur-md px-2 py-1 rounded-lg flex items-center gap-1 border border-neutral-200 dark:border-white/10 shadow-lg">
                      <i className="fa-solid fa-star text-amber-500 text-[8px]"></i>
                      <span className="text-[10px] font-black text-neutral-900 dark:text-white">{book.averageRating}</span>
                   </div>
                </div>
              </div>
              <h3 className="font-bold text-sm md:text-base mb-0.5 line-clamp-1 text-neutral-900 dark:text-white uppercase italic tracking-tight">{book.title}</h3>
              <p className="text-[11px] md:text-xs text-neutral-600 dark:text-neutral-400 font-black uppercase tracking-widest truncate leading-tight">By {book.authorName}</p>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-12 md:space-y-20 pb-32 max-w-screen-2xl mx-auto overflow-x-hidden theme-transition">
      
      {/* Hero Section */}
      <section className="relative min-h-[500px] md:h-[650px] rounded-[3rem] overflow-hidden group shadow-2xl border border-neutral-200 dark:border-white/5">
        <img src={heroContent.backgroundImage} className="absolute inset-0 w-full h-full object-cover scale-100 transition-transform duration-[15s] ease-linear" alt="Hero" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
        
        {user.role === 'admin' && (
          <div className="absolute top-6 right-6 z-50">
            <input type="file" ref={heroFileInputRef} className="hidden" accept="image/*" onChange={handleHeroUpload} />
            <button onClick={() => heroFileInputRef.current?.click()} className="bg-black/60 hover:bg-black/80 backdrop-blur-xl border border-white/20 text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 transition-all shadow-2xl">
              <i className="fa-solid fa-image"></i> Upload Hero Image
            </button>
          </div>
        )}

        <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-20 lg:px-24 max-w-5xl space-y-6 md:space-y-8">
          <div className="flex items-center gap-3">
            <span className="bg-indigo-600 px-4 py-1.5 rounded-full text-[10px] font-black text-white uppercase tracking-[0.3em] shadow-xl border border-white/10">Now Trending</span>
            {saleConfig.isActive && <span className="bg-amber-500 px-4 py-1.5 rounded-full text-[10px] font-black text-white uppercase tracking-[0.3em] animate-pulse">{saleConfig.campaignName}</span>}
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl xl:text-8xl font-black leading-[0.9] hero-text-shadow tracking-tighter uppercase italic text-white -ml-1">
            {heroContent.titlePrefix} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-indigo-400 to-indigo-600">{heroContent.titleHighlight}</span>
          </h1>
          
          <p className="text-neutral-200 text-sm md:text-lg font-medium max-w-xl hero-text-shadow leading-relaxed italic opacity-90">{heroContent.description}</p>
          
          <div className="flex flex-wrap gap-4 pt-4">
            <button onClick={() => onNavigate(Page.EXPLORE)} className="bg-white text-black px-10 py-4 rounded-2xl font-black text-xs md:text-sm uppercase tracking-[0.2em] shadow-2xl hover:bg-indigo-600 hover:text-white transition-all transform hover:-translate-y-1">{heroContent.primaryButton}</button>
            <button onClick={() => onNavigate(Page.STUDIO)} className="bg-black/40 hover:bg-white/10 backdrop-blur-xl text-white border border-white/20 px-10 py-4 rounded-2xl font-black text-xs md:text-sm uppercase tracking-[0.2em] transition-all transform hover:-translate-y-1">{heroContent.secondaryButton}</button>
          </div>
        </div>
      </section>

      {/* Newest Chapters - horizontal scroll row */}
      {latestScenes.length > 0 && (
        <div className="space-y-6 px-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xl md:text-2xl font-black flex items-center gap-3 tracking-tight text-neutral-900 dark:text-white uppercase italic">
              <i className="fa-solid fa-microphone text-indigo-500"></i> Latest Narrative Drops
            </h2>
            <div className="flex items-center gap-2">
               <span className="text-[10px] font-black uppercase text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-3 py-1 rounded-full">New Content</span>
            </div>
          </div>
          <div className="flex gap-4 md:gap-5 overflow-x-auto pb-4 hide-scrollbar -mx-2 px-2 snap-x">
            {latestScenes.map(({ scene, book }, idx) => (
              <div key={scene.id} className="snap-start shrink-0 w-32 md:w-40 group cursor-pointer" onClick={() => onSelectBook(book)}>
                <div className="relative aspect-square rounded-2xl overflow-hidden border-2 border-neutral-200 dark:border-white/5 shadow-lg bg-neutral-900">
                  <img src={scene.visualAssets[0]?.url || book.coverImage} className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700" alt="" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
                    <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mb-2 group-hover:bg-indigo-600 group-hover:border-indigo-500 transition-all">
                      <i className="fa-solid fa-play text-white text-[10px]"></i>
                    </div>
                    <p className="text-[10px] font-black text-white uppercase italic leading-none drop-shadow-md">{book.title}</p>
                    <p className="text-[8px] font-bold text-neutral-300 uppercase tracking-tighter mt-1">Scene {scene.sceneNumber}</p>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/5 overflow-hidden">
                    <div className="h-full bg-indigo-500" style={{ width: `${Math.random() * 60 + 20}%` }}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-20">
        {recentlyPlayedBooks.length > 0 && (
          <div className="space-y-4 px-2">
            <h2 className="text-xl md:text-2xl font-black flex items-center gap-3 tracking-tight text-neutral-900 dark:text-white uppercase italic">
              <i className="fa-solid fa-clock-rotate-left text-indigo-500"></i> Jump Back In
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentlyPlayedBooks.slice(0, 3).map(book => (
                <div key={book.id} onClick={() => onSelectBook(book)} className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2rem] p-4 flex gap-4 cursor-pointer hover:border-indigo-500 transition-all group shadow-lg">
                   <div className="w-20 aspect-[3/4] rounded-xl overflow-hidden shrink-0 shadow-lg">
                      <img src={book.coverImage} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                   </div>
                   <div className="flex flex-col justify-center flex-1 min-w-0">
                      <h3 className="font-bold text-neutral-900 dark:text-white truncate uppercase italic">{book.title}</h3>
                      <p className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mt-1 truncate">By {book.authorName}</p>
                      <div className="mt-3 space-y-1">
                         <div className="flex justify-between text-[8px] font-black uppercase text-indigo-600"><span>Progress</span><span>Resume</span></div>
                         <div className="h-1 w-full bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden"><div className="h-full bg-indigo-600 w-2/3"></div></div>
                      </div>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <Section title="Trending on Hub" books={trendingThisWeek} icon="fa-bolt-lightning" color="text-amber-400" />

        {/* Promo Banner */}
        <div className="relative overflow-hidden rounded-[3rem] p-8 md:p-12 shadow-2xl group border border-neutral-200 dark:border-white/5 mx-2 min-h-[280px] flex items-center">
           <img src={promoBanner.bgImage} className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" alt="Promo" />
           <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
           
           {user.role === 'admin' && (
             <div className="absolute top-6 right-6 z-30 opacity-0 group-hover:opacity-100 transition-opacity">
                <input type="file" ref={promoFileInputRef} className="hidden" accept="image/*" onChange={handlePromoUpload} />
                <button onClick={() => promoFileInputRef.current?.click()} className="bg-black/60 hover:bg-black/80 backdrop-blur-xl border border-white/20 text-white px-5 py-2.5 rounded-2xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 transition-all shadow-xl">
                  <i className="fa-solid fa-cloud-arrow-up"></i> Upload Desktop Image
                </button>
             </div>
           )}

           <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-10 w-full max-w-7xl mx-auto px-4">
              <div className="space-y-4 max-w-xl text-center md:text-left">
                 <h2 className="text-4xl md:text-6xl font-black text-white uppercase italic tracking-tighter leading-[0.9] drop-shadow-2xl">{promoBanner.title}</h2>
                 <p className="text-neutral-200 text-sm md:text-lg font-medium tracking-wide">{promoBanner.subtitle}</p>
              </div>
              <button onClick={() => onNavigate(Page.STUDIO)} className="bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-5 rounded-2xl font-black text-xs md:text-sm uppercase tracking-[0.2em] shadow-2xl shadow-indigo-600/40 transition-all transform hover:-translate-y-1">{promoBanner.cta} <i className="fa-solid fa-arrow-right ml-2"></i></button>
           </div>
        </div>

        <Section title="Premium Selections" books={popularOnAQ} icon="fa-chart-line" color="text-emerald-500" />
      </div>
    </div>
  );
};

export default Home;
