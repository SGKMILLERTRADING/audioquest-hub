
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { User, Book, Scene, Page, VisualAsset, TransitionType } from '../types';
import { generateBookDescription, generateCoverImage } from '../services/geminiService';

interface WriterStudioProps {
  user: User;
  books: Book[];
  onAddBook: (book: Book, scene: Scene) => void;
  onAddScene: (bookId: string, scene: Scene) => void;
  onNavigate: (page: Page) => void;
  categories: string[];
}

const WriterStudio: React.FC<WriterStudioProps> = ({ user, books, onAddBook, onAddScene, categories }) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'manage'>('upload');
  const [step, setStep] = useState(1);
  const [selectedBookForChapters, setSelectedBookForChapters] = useState<Book | null>(null);
  const [showReviewMode, setShowReviewMode] = useState(false);
  const [reviewProgress, setReviewProgress] = useState(0);
  const [reviewStatus, setReviewStatus] = useState('Initializing Safety Scan...');
  const [bookSearchTerm, setBookSearchTerm] = useState('');
  
  const [isUploadingAudio, setIsUploadingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  const coverInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const timelineInputRef = useRef<HTMLInputElement>(null);
  
  // Filter books by title or author
  const myBooks = useMemo(() => {
    return books.filter(b => b.authorId === user.id)
                .filter(b => b.title.toLowerCase().includes(bookSearchTerm.toLowerCase()) || 
                             b.authorName.toLowerCase().includes(bookSearchTerm.toLowerCase()));
  }, [books, user.id, bookSearchTerm]);

  // Load drafts from localStorage
  const [formData, setFormData] = useState(() => {
    const saved = localStorage.getItem(`aq_draft_book_${user.id}`);
    if (saved) {
      try {
        return { ...JSON.parse(saved), audioFile: null };
      } catch (e) { console.error("Draft recovery failed", e); }
    }
    return {
      title: '', category: categories[0] || 'Fantasy', description: '', sceneTitle: '', coverPreview: '',
      duration: '04:00', cost: 15, uploadDate: new Date().toISOString().split('T')[0],
      audioFile: null as File | null, visualAssets: [] as VisualAsset[]
    };
  });

  const [newSceneData, setNewSceneData] = useState(() => {
    const saved = localStorage.getItem(`aq_draft_scene_${user.id}`);
    if (saved) {
      try {
        return { ...JSON.parse(saved), audioFile: null };
      } catch (e) { console.error("Draft recovery failed", e); }
    }
    return {
      title: '', chapterNumber: 1, partNumber: 1, sceneNumber: 1,
      duration: '04:00', cost: 15, uploadDate: new Date().toISOString().split('T')[0],
      audioFile: null as File | null, visualAssets: [] as VisualAsset[]
    };
  });

  // Save drafts to localStorage
  useEffect(() => {
    const dataToSave = { ...formData, audioFile: null };
    localStorage.setItem(`aq_draft_book_${user.id}`, JSON.stringify(dataToSave));
  }, [formData, user.id]);

  useEffect(() => {
    const dataToSave = { ...newSceneData, audioFile: null };
    localStorage.setItem(`aq_draft_scene_${user.id}`, JSON.stringify(dataToSave));
  }, [newSceneData, user.id]);

  const formDataRef = useRef(formData);
  const newSceneDataRef = useRef(newSceneData);
  const selectedBookRef = useRef(selectedBookForChapters);

  useEffect(() => { formDataRef.current = formData; }, [formData]);
  useEffect(() => { newSceneDataRef.current = newSceneData; }, [newSceneData]);
  useEffect(() => { selectedBookRef.current = selectedBookForChapters; }, [selectedBookForChapters]);

  const parseDurationInput = (input: string): string => {
    const cleaned = input.trim().toLowerCase();
    const match = cleaned.match(/^(?:(\d+)\s*m)?\s*(?:(\d+)\s*s)?$/i);
    if (match && (match[1] || match[2])) {
      const mins = match[1] ? parseInt(match[1]) : 0;
      const secs = match[2] ? parseInt(match[2]) : 0;
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    if (/^\d{1,2}:\d{2}$/.test(cleaned)) {
      const [m, s] = cleaned.split(':');
      return `${m.padStart(2, '0')}:${s.padStart(2, '0')}`;
    }
    return cleaned || '04:00';
  };

  const handleDurationBlur = (target: 'book' | 'scene') => {
    if (target === 'book') {
      setFormData(prev => ({ ...prev, duration: parseDurationInput(prev.duration) }));
    } else {
      setNewSceneData(prev => ({ ...prev, duration: parseDurationInput(prev.duration) }));
    }
  };

  const handleCostChange = (val: string, target: 'book' | 'scene') => {
    const cost = Math.max(0, parseInt(val) || 0);
    if (target === 'book') setFormData(prev => ({ ...prev, cost }));
    else setNewSceneData(prev => ({ ...prev, cost }));
  };

  const handleAiDescription = async () => {
    if (!formData.title) return alert("Enter a title first.");
    setIsAiGenerating(true);
    const blurb = await generateBookDescription(formData.title, formData.category);
    setFormData(prev => ({ ...prev, description: blurb || prev.description }));
    setIsAiGenerating(false);
  };

  const handleAiCover = async () => {
    if (!formData.title) return alert("Enter a title for the AI prompt.");
    setIsAiGenerating(true);
    const imageUrl = await generateCoverImage(formData.title + " " + formData.category);
    if (imageUrl) setFormData(prev => ({ ...prev, coverPreview: imageUrl }));
    setIsAiGenerating(false);
  };

  const simulateAudioUpload = () => {
    setIsUploadingAudio(true);
    setAudioProgress(0);
    const interval = setInterval(() => {
      setAudioProgress(prev => {
        if (prev >= 100) { clearInterval(interval); setTimeout(() => setIsUploadingAudio(false), 500); return 100; }
        return prev + 10;
      });
    }, 150);
  };

  const handleAssetUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'book' | 'scene') => {
    const files = e.target.files;
    if (!files) return;
    const currentAssets = target === 'book' ? formData.visualAssets : newSceneData.visualAssets;
    
    if (currentAssets.length >= 6) return alert("Sequence reached capacity (6 Clips max).");
    
    const newAssets: VisualAsset[] = (Array.from(files) as File[]).slice(0, 6 - currentAssets.length).map((file, index) => ({
      id: `asset_${Date.now()}_${index}`,
      url: URL.createObjectURL(file),
      type: file.type.startsWith('video') ? 'video' : 'image',
      duration: 8,
      isMuted: true,
      transitionType: 'fade'
    }));

    if (target === 'book') setFormData(prev => ({ ...prev, visualAssets: [...prev.visualAssets, ...newAssets] }));
    else setNewSceneData(prev => ({ ...prev, visualAssets: [...prev.visualAssets, ...newAssets] }));
  };

  const updateAsset = (id: string, updates: Partial<VisualAsset>, target: 'book' | 'scene') => {
    if (target === 'book') {
      setFormData(prev => ({ ...prev, visualAssets: prev.visualAssets.map(a => a.id === id ? { ...a, ...updates } : a) }));
    } else {
      setNewSceneData(prev => ({ ...prev, visualAssets: prev.visualAssets.map(a => a.id === id ? { ...a, ...updates } : a) }));
    }
  };

  const finalizeLaunch = useCallback(() => {
    const currentSelectedBook = selectedBookRef.current;
    const currentNewSceneData = newSceneDataRef.current;
    const currentFormData = formDataRef.current;

    try {
      if (currentSelectedBook) {
        if (!currentNewSceneData.audioFile) {
          alert("Narration asset required to finish sync.");
          setShowReviewMode(false);
          return;
        }
        
        const scene: Scene = {
          id: `s${currentNewSceneData.sceneNumber}_p${currentNewSceneData.partNumber}_c${currentNewSceneData.chapterNumber}_${Date.now()}`,
          bookId: currentSelectedBook.id, 
          title: currentNewSceneData.title || 'Untitled Sequence',
          audioUrl: URL.createObjectURL(currentNewSceneData.audioFile), 
          visualAssets: currentNewSceneData.visualAssets,
          duration: currentNewSceneData.duration, 
          cost: currentNewSceneData.cost, 
          order: Date.now(),
          uploadDate: currentNewSceneData.uploadDate, 
          chapterNumber: currentNewSceneData.chapterNumber,
          partNumber: currentNewSceneData.partNumber, 
          sceneNumber: currentNewSceneData.sceneNumber
        };
        
        onAddScene(currentSelectedBook.id, scene);
        localStorage.removeItem(`aq_draft_scene_${user.id}`);
        setNewSceneData({
          title: '', chapterNumber: 1, partNumber: 1, sceneNumber: 1,
          duration: '04:00', cost: 15, uploadDate: new Date().toISOString().split('T')[0],
          audioFile: null, visualAssets: []
        });
      } else {
        if (!currentFormData.audioFile) {
          alert("Master narration required for story hub launch.");
          setShowReviewMode(false);
          return;
        }

        const newBook: Book = {
          id: `book_${Date.now()}`, 
          authorId: user.id, 
          authorName: user.username,
          title: currentFormData.title, 
          description: currentFormData.description, 
          coverImage: currentFormData.coverPreview,
          category: currentFormData.category, 
          totalChapters: 1, 
          averageRating: 0, 
          isCompleted: false, 
          listenerCount: 0
        };

        const firstScene: Scene = {
          id: `s1_p1_c0_${Date.now()}`, 
          bookId: newBook.id, 
          title: currentFormData.sceneTitle || 'Prologue',
          audioUrl: URL.createObjectURL(currentFormData.audioFile), 
          visualAssets: currentFormData.visualAssets,
          duration: currentFormData.duration, 
          cost: 0, 
          order: 1, 
          uploadDate: currentFormData.uploadDate,
          chapterNumber: 0, 
          partNumber: 1, 
          sceneNumber: 1
        };

        onAddBook(newBook, firstScene);
        localStorage.removeItem(`aq_draft_book_${user.id}`);
        setFormData({
          title: '', category: categories[0] || 'Fantasy', description: '', sceneTitle: '', coverPreview: '',
          duration: '04:00', cost: 15, uploadDate: new Date().toISOString().split('T')[0],
          audioFile: null, visualAssets: []
        });
      }

      setShowReviewMode(false);
      setReviewProgress(0);
      setActiveTab('manage');
      setSelectedBookForChapters(null);
      setStep(1);
    } catch (err) {
      console.error("Critical Publishing Failure:", err);
      alert("Encountered an error while finalizing your sequence.");
      setShowReviewMode(false);
      setReviewProgress(0);
    }
  }, [user, onAddBook, onAddScene, categories]);

  useEffect(() => {
    let interval: any;
    if (showReviewMode) {
      interval = setInterval(() => {
        setReviewProgress(prev => {
          if (prev >= 100) { 
            clearInterval(interval); 
            return 100; 
          }
          if (prev === 20) setReviewStatus('Analyzing Narrative Consistency...');
          if (prev === 60) setReviewStatus('Sequencing Audio Tracks...');
          if (prev === 85) setReviewStatus('Finalizing Cloud Identity...');
          return prev + 5;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [showReviewMode]);

  useEffect(() => {
    if (reviewProgress === 100 && showReviewMode) {
      const timer = setTimeout(finalizeLaunch, 600);
      return () => clearTimeout(timer);
    }
  }, [reviewProgress, showReviewMode, finalizeLaunch]);

  const handleStartReview = () => {
    const isReady = selectedBookForChapters 
      ? (newSceneData.audioFile && newSceneData.visualAssets.length > 0)
      : (formData.audioFile && formData.visualAssets.length > 0 && formData.title);
      
    if (!isReady) {
      alert("Sync Validation Failed: Narration audio and visual elements are mandatory.");
      return;
    }

    setReviewProgress(0);
    setReviewStatus('Initializing Safety Scan...');
    setShowReviewMode(true);
  };

  const Timeline = ({ assets, target }: { assets: VisualAsset[], target: 'book' | 'scene' }) => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-black uppercase text-neutral-400 tracking-widest italic">Sequence Stream: {assets.length}/6 Clips (Muted by Default)</p>
        <button onClick={() => timelineInputRef.current?.click()} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase shadow-lg hover:bg-indigo-500 transition-colors">Add Video Clips</button>
      </div>
      <div className="bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-4 flex gap-4 overflow-x-auto min-h-[220px] visual-timeline-scroll">
        {assets.map((asset, index) => (
          <div key={asset.id} className="relative group shrink-0 w-40 rounded-2xl overflow-hidden bg-black shadow-lg flex flex-col border border-white/5">
            <div className="relative h-24">
              {asset.type === 'video' ? <video src={asset.url} className="w-full h-full object-cover opacity-60" muted /> : <img src={asset.url} className="w-full h-full object-cover opacity-60" />}
              <div className="absolute top-2 right-2 flex gap-1">
                <button 
                  onClick={() => updateAsset(asset.id, { isMuted: !asset.isMuted }, target)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] transition-all ${asset.isMuted ? 'bg-rose-500 text-white shadow-lg' : 'bg-white/20 text-white hover:bg-white/30'}`}
                >
                  <i className={`fa-solid ${asset.isMuted ? 'fa-volume-xmark' : 'fa-volume-high'}`}></i>
                </button>
              </div>
              <span className="absolute bottom-2 left-2 text-[7px] font-black text-white uppercase bg-black/40 px-2 py-0.5 rounded">Clip {index + 1}</span>
            </div>
            <div className="p-3 space-y-2">
              <label className="text-[8px] font-black uppercase text-neutral-500 block tracking-widest">Transition Effect</label>
              <select 
                value={asset.transitionType}
                onChange={(e) => updateAsset(asset.id, { transitionType: e.target.value as TransitionType }, target)}
                className="w-full bg-neutral-50 dark:bg-neutral-800 text-[10px] font-black uppercase rounded p-1.5 outline-none border border-neutral-200 dark:border-neutral-700"
              >
                <option value="fade">Fade</option>
                <option value="slide">Slide</option>
                <option value="zoom">Zoom</option>
                <option value="blur">Blur</option>
                <option value="cut">Cut</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20">
      <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) setFormData(prev => ({ ...prev, coverPreview: URL.createObjectURL(file) }));
      }} />
      <input type="file" ref={audioInputRef} className="hidden" accept="audio/*" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) {
          if (selectedBookForChapters) setNewSceneData(prev => ({ ...prev, audioFile: file }));
          else setFormData(prev => ({ ...prev, audioFile: file }));
          simulateAudioUpload();
        }
      }} />
      <input type="file" ref={timelineInputRef} multiple className="hidden" accept="video/*,image/*" onChange={(e) => handleAssetUpload(e, selectedBookForChapters ? 'scene' : 'book')} />

      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-black italic uppercase text-neutral-900 dark:text-white tracking-tighter">Creator Studio</h1>
        <div className="flex bg-neutral-100 dark:bg-neutral-900 p-1 rounded-2xl border border-neutral-200 dark:border-neutral-800 shadow-sm">
          <button onClick={() => {setActiveTab('upload'); setStep(1); setSelectedBookForChapters(null);}} className={`px-6 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${activeTab === 'upload' ? 'bg-indigo-600 text-white shadow-lg' : 'text-neutral-500'}`}>New Creation</button>
          <button onClick={() => {setActiveTab('manage'); setSelectedBookForChapters(null);}} className={`px-6 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${activeTab === 'manage' ? 'bg-indigo-600 text-white shadow-lg' : 'text-neutral-500'}`}>Manage Hubs</button>
        </div>
      </div>

      {showReviewMode && (
        <div className="fixed inset-0 z-[120] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-10 text-center animate-in fade-in">
           <div className="w-full max-w-xl space-y-8">
              <div className="relative w-32 h-32 mx-auto">
                 <div className="absolute inset-0 rounded-full border-4 border-white/5 border-t-indigo-600 animate-spin"></div>
                 <div className="absolute inset-0 flex items-center justify-center text-white font-black text-2xl">{reviewProgress}%</div>
              </div>
              <div className="space-y-2">
                 <h2 className="text-3xl font-black text-white uppercase italic tracking-tighter">{reviewStatus}</h2>
                 <p className="text-neutral-400 text-xs font-black uppercase tracking-[0.2em]">Syncing Narrative to Hub Treasury</p>
              </div>
              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                 <div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${reviewProgress}%` }}></div>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'upload' ? (
        <div className="bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] shadow-2xl p-10 space-y-10 animate-in fade-in">
           {step === 1 && (
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
               <div className="space-y-4">
                 <div onClick={() => coverInputRef.current?.click()} className="aspect-square bg-neutral-50 dark:bg-neutral-900 border-2 border-dashed rounded-[2rem] flex items-center justify-center cursor-pointer relative overflow-hidden group">
                   {formData.coverPreview ? <img src={formData.coverPreview} className="absolute inset-0 w-full h-full object-cover" /> : <p className="text-[10px] font-black uppercase text-neutral-400">Manual Cover Upload</p>}
                 </div>
                 <button onClick={handleAiCover} disabled={isAiGenerating} className="w-full bg-amber-500/10 text-amber-600 border border-amber-500/20 py-3 rounded-xl font-black text-[9px] uppercase tracking-widest">
                   {isAiGenerating ? 'Generating Art...' : 'AI Generate Cover'}
                 </button>
               </div>
               <div className="space-y-4">
                 <input type="text" placeholder="Story Hub Title" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-2xl px-5 py-4 text-sm font-bold" />
                 <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-2xl px-5 py-4 text-sm font-bold">{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
                 <div className="space-y-2">
                   <textarea placeholder="Compelling Synopsis..." rows={4} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-2xl px-5 py-4 text-sm font-bold resize-none"></textarea>
                   <button onClick={handleAiDescription} disabled={isAiGenerating} className="w-full bg-indigo-600/10 text-indigo-600 border border-indigo-500/20 py-3 rounded-xl font-black text-[9px] uppercase tracking-widest">
                     {isAiGenerating ? 'AI Thinking...' : 'AI Draft Description'}
                   </button>
                 </div>
                 <button onClick={() => setStep(2)} className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-xs uppercase shadow-xl tracking-widest mt-4 hover:bg-indigo-500 transition-colors">Next Phase</button>
               </div>
             </div>
           )}

           {step === 2 && (
             <div className="space-y-8 animate-in slide-in-from-bottom-4">
               <div onClick={() => audioInputRef.current?.click()} className={`border-2 border-dashed rounded-[3rem] p-12 text-center cursor-pointer transition-all ${formData.audioFile ? 'bg-indigo-600 text-white border-indigo-500 shadow-xl' : 'border-neutral-200 dark:border-neutral-800 hover:border-indigo-600'}`}>
                 <p className="font-black text-xs uppercase tracking-widest">{formData.audioFile ? 'Master Narration Locked' : 'Select Master Narration'}</p>
                 {isUploadingAudio && <div className="w-full h-1 bg-white/20 rounded-full mt-4 overflow-hidden"><div className="h-full bg-white transition-all duration-300" style={{ width: `${audioProgress}%` }}></div></div>}
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <div className="space-y-1">
                   <label className="text-[8px] font-black uppercase tracking-widest text-neutral-400 px-2">Duration (e.g. 4m30s)</label>
                   <input 
                    type="text" 
                    value={formData.duration} 
                    onChange={e => setFormData({...formData, duration: e.target.value})} 
                    onBlur={() => handleDurationBlur('book')}
                    className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-bold" 
                   />
                 </div>
                 <div className="space-y-1">
                   <label className="text-[8px] font-black uppercase tracking-widest text-neutral-400 px-2">Unlock Cost (Coins)</label>
                   <input 
                    type="number" 
                    value={formData.cost} 
                    onChange={e => handleCostChange(e.target.value, 'book')} 
                    className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-black text-indigo-600" 
                   />
                 </div>
                 <div className="space-y-1">
                   <label className="text-[8px] font-black uppercase tracking-widest text-neutral-400 px-2">Scheduled Release</label>
                   <input type="date" value={formData.uploadDate} onChange={e => setFormData({...formData, uploadDate: e.target.value})} className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-bold" />
                 </div>
               </div>
               <Timeline assets={formData.visualAssets} target="book" />
               <div className="flex gap-4">
                  <button onClick={() => setStep(1)} className="flex-1 bg-neutral-100 dark:bg-neutral-900 py-4 rounded-2xl font-black text-[10px] uppercase border border-neutral-200 dark:border-neutral-800">Back</button>
                  <button onClick={handleStartReview} className="flex-2 bg-indigo-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase shadow-xl hover:bg-indigo-500 transition-colors">Publish Narrative</button>
               </div>
             </div>
           )}
        </div>
      ) : (
        <div className="grid gap-8">
           {selectedBookForChapters ? (
             <div className="bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-[3rem] p-10 space-y-8 animate-in zoom-in-95">
                <div className="flex justify-between items-center">
                   <div className="flex items-center gap-3">
                      <button onClick={() => setSelectedBookForChapters(null)} className="text-neutral-400 hover:text-indigo-600 transition-colors"><i className="fa-solid fa-arrow-left"></i></button>
                      <h3 className="text-xl font-black uppercase italic text-neutral-900 dark:text-white">Compose: {selectedBookForChapters.title}</h3>
                   </div>
                   <button onClick={() => setSelectedBookForChapters(null)} className="text-neutral-400 hover:text-rose-500"><i className="fa-solid fa-xmark text-2xl"></i></button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Chapter #</label><input type="number" value={newSceneData.chapterNumber} onChange={e => setNewSceneData({...newSceneData, chapterNumber: parseInt(e.target.value) || 0})} className="w-full bg-neutral-100 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-sm font-bold" /></div>
                  <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Part #</label><input type="number" value={newSceneData.partNumber} onChange={e => setNewSceneData({...newSceneData, partNumber: parseInt(e.target.value) || 1})} className="w-full bg-neutral-100 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-sm font-bold" /></div>
                  <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Scene #</label><input type="number" value={newSceneData.sceneNumber} onChange={e => setNewSceneData({...newSceneData, sceneNumber: parseInt(e.target.value) || 1})} className="w-full bg-neutral-100 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 rounded-xl px-4 py-3 text-sm font-bold" /></div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Duration (e.g. 4m30s)</label>
                    <input 
                      type="text" 
                      value={newSceneData.duration} 
                      onChange={e => setNewSceneData({...newSceneData, duration: e.target.value})} 
                      onBlur={() => handleDurationBlur('scene')}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-bold" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Unlock Cost (Coins)</label>
                    <input 
                      type="number" 
                      value={newSceneData.cost} 
                      onChange={e => handleCostChange(e.target.value, 'scene')} 
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-black text-indigo-600" 
                    />
                  </div>
                  <div className="space-y-1"><label className="text-[8px] font-black uppercase text-neutral-400 ml-2">Release Date</label><input type="date" value={newSceneData.uploadDate} onChange={e => setNewSceneData({...newSceneData, uploadDate: e.target.value})} className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl px-5 py-4 text-sm font-bold" /></div>
                </div>
                <div onClick={() => audioInputRef.current?.click()} className={`w-full py-6 border-2 border-dashed rounded-xl font-black text-[9px] uppercase transition-all text-center cursor-pointer ${newSceneData.audioFile ? 'bg-indigo-600 text-white border-indigo-500 shadow-xl' : 'border-neutral-200 dark:border-neutral-800 text-neutral-500 hover:border-indigo-500'}`}>
                  {newSceneData.audioFile ? 'Narration Locked: ' + newSceneData.audioFile.name : 'Select Narration Audio File'}
                </div>
                {isUploadingAudio && selectedBookForChapters && <div className="w-full h-1.5 bg-neutral-100 dark:bg-neutral-900 rounded-full overflow-hidden"><div className="h-full bg-indigo-600 transition-all duration-300" style={{ width: `${audioProgress}%` }}></div></div>}
                <Timeline assets={newSceneData.visualAssets} target="scene" />
                <button onClick={handleStartReview} className="w-full bg-indigo-600 py-5 rounded-2xl font-black text-white text-xs uppercase shadow-xl tracking-widest transition-all active:scale-95 hover:bg-indigo-500">Publish Narrative Sequence</button>
             </div>
           ) : (
             <div className="space-y-6">
                <div className="max-w-md">
                   <div className="relative group">
                      <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 transition-colors group-focus-within:text-indigo-500"></i>
                      <input 
                        type="text" 
                        placeholder="Search story hubs by title or author..." 
                        value={bookSearchTerm}
                        onChange={(e) => setBookSearchTerm(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border-2 border-neutral-200 dark:border-neutral-800 rounded-2xl py-3.5 pl-12 pr-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:border-indigo-500 shadow-sm transition-all"
                      />
                   </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {myBooks.map(book => (
                    <div key={book.id} onClick={() => setSelectedBookForChapters(book)} className="relative bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] p-4 shadow-lg group cursor-pointer hover:-translate-y-1 hover:border-indigo-500 transition-all">
                      <img src={book.coverImage} className="w-full aspect-[3/4] object-cover rounded-3xl mb-3 shadow-md" alt="" />
                      <h4 className="text-sm font-black uppercase text-neutral-900 dark:text-white truncate italic tracking-tighter">{book.title}</h4>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-[8px] font-black text-neutral-400 uppercase tracking-widest">{book.category}</span>
                        <div className="flex gap-1">
                          <i className="fa-solid fa-star text-amber-500 text-[8px]"></i>
                          <span className="text-[8px] font-black text-neutral-500">{book.averageRating}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div onClick={() => setActiveTab('upload')} className="aspect-[3/4] border-2 border-dashed border-neutral-200 dark:border-neutral-800 rounded-[2.5rem] flex flex-col items-center justify-center gap-3 text-neutral-400 cursor-pointer hover:border-indigo-600 hover:text-indigo-600 transition-all group">
                    <div className="w-12 h-12 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all">
                      <i className="fa-solid fa-plus text-xl"></i>
                    </div>
                    <p className="text-[10px] font-black uppercase tracking-widest">New Story Hub</p>
                  </div>
                </div>
             </div>
           )}
        </div>
      )}
    </div>
  );
};

export default WriterStudio;
